<template>
    <div class="container mt-5">
        <div class="col-12 text-center">
            <h1>TestvBlogs</h1>
            <a href="#" target="_blank">Visit For More Blogs</a>
        </div>
    </div>
</template>
